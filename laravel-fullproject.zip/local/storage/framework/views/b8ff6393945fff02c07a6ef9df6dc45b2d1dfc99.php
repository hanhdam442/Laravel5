<h1>This is MyFirst View</h1>
<?php echo e($user); ?>