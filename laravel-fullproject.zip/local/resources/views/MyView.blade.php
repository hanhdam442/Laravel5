<h1>This is MyFirst View</h1>
{{$user}}