@extends('layout.master')

@section('content')
<div class="container">
<h1>This is page category {{$category}}</h1>
</div>
@endsection