<div class="container">
	<div class="foot-main">					
		<div class="row">
			<div class="col-xs-12 col-sm-2 col-md-2">
				<div class="list-socical">
					<ul class="social">
						<li class="facebook">
							<a href="#"><i class="fa fa-facebook"></i></a>
						</li>
						<li class="twitter">
							<a href="#"><i class="fa fa-twitter"></i></a>
						</li>
						<li class="youtube">
							<a href="#"><i class="fa fa-youtube"></i></a>
						</li>
					</ul>
				</div>
			</div>
			<div class="col-xs-12 col-sm-5 col-md-5">
				<p>167 Trau Quy Gia Lam, Ha Noi</p>
				<p><span>Phone:</span> 012-345-6789</p>
				<p>yourmail@your.mail.com</p>
			</div>
			<div class="col-xs-12 col-sm-5 col-md-5 ">					
				<p>We have divided the range of our services and other into six clearly- arranged product lines.</p>
				<p>There is a group of guarantors for each product line.</p>
			</div>						
		</div>
	</div>
</div>
<div class="foot-bot">
	<p>� Theme by xxx.com 2014 All rights reserved</p>
</div>