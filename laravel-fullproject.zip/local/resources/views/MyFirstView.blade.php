@extends('MyView')

<h1>test</h1>

{{$user}}